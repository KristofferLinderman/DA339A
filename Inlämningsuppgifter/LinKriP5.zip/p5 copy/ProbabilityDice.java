package p5;

public class ProbabilityDice implements Dice {

	public ProbabilityDice(int[] is) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int throwDice() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getSides() {
		// TODO Auto-generated method stub
		return 0;
	}

}
